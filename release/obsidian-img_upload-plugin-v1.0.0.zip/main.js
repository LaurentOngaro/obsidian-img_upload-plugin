var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __markAsModule = (target) => __defProp(target, "__esModule", { value: true });
var __export = (target, all) => {
  __markAsModule(target);
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __reExport = (target, module2, desc) => {
  if (module2 && typeof module2 === "object" || typeof module2 === "function") {
    for (let key of __getOwnPropNames(module2))
      if (!__hasOwnProp.call(target, key) && key !== "default")
        __defProp(target, key, { get: () => module2[key], enumerable: !(desc = __getOwnPropDesc(module2, key)) || desc.enumerable });
  }
  return target;
};
var __toModule = (module2) => {
  return __reExport(__markAsModule(__defProp(module2 != null ? __create(__getProtoOf(module2)) : {}, "default", module2 && module2.__esModule && "default" in module2 ? { get: () => module2.default, enumerable: true } : { value: module2, enumerable: true })), module2);
};

// src/main.ts
__export(exports, {
  default: () => CloudinaryPlugin,
  processFileCreate: () => processFileCreate
});
var import_obsidian = __toModule(require("obsidian"));

// src/cloudinary.ts
var CloudinaryUploader = class {
  constructor(settings) {
    this.settings = settings;
  }
  async upload(fileOrBlob, filename) {
    const formData = new FormData();
    if (fileOrBlob instanceof File) {
      formData.append("file", fileOrBlob);
    } else {
      const name = filename || `upload-${Date.now()}.png`;
      formData.append("file", fileOrBlob, name);
    }
    if (this.settings.upload_preset) {
      formData.append("upload_preset", this.settings.upload_preset);
    }
    if (this.settings.api_secret) {
      if (!this.settings.api_key) {
        throw new Error("Signed uploads require api_key and api_secret");
      }
      const timestamp = Math.floor(Date.now() / 1e3);
      const signature = await sha1Hex(`timestamp=${timestamp}${this.settings.api_secret}`);
      formData.append("timestamp", String(timestamp));
      formData.append("api_key", this.settings.api_key);
      formData.append("signature", signature);
    } else if (this.settings.api_key) {
      formData.append("api_key", this.settings.api_key);
    }
    const url = `https://api.cloudinary.com/v1_1/${this.settings.cloud_name}/image/upload`;
    const response = await fetch(url, {
      method: "POST",
      body: formData
    });
    if (!response.ok) {
      let bodyText = await response.text();
      try {
        const json = JSON.parse(bodyText);
        const message = json.error?.message || bodyText;
        throw new Error(`Upload failed: ${response.status} ${message}`);
      } catch (e) {
        throw new Error(`Upload failed: ${response.status} ${bodyText}`);
      }
    }
    const data = await response.json();
    return data.secure_url;
  }
};
async function sha1Hex(input) {
  if (typeof crypto !== "undefined" && crypto.subtle) {
    const enc = new TextEncoder();
    const buf = await crypto.subtle.digest("SHA-1", enc.encode(input));
    return Array.from(new Uint8Array(buf)).map((b) => b.toString(16).padStart(2, "0")).join("");
  }
  try {
    const nodeCrypto = await import("crypto");
    return nodeCrypto.createHash("sha1").update(input).digest("hex");
  } catch (e) {
    throw new Error("No SHA-1 implementation available");
  }
}

// src/paste.ts
async function pasteClipboardImage(settings, uploader, clipboard) {
  const clipboardAPI = clipboard ?? (typeof navigator !== "undefined" ? navigator.clipboard : void 0);
  if (!clipboardAPI || !clipboardAPI.read)
    throw new Error("Clipboard read not supported");
  const items = await clipboardAPI.read();
  const clipboardItem = items.find((item) => item.types && item.types.some((t) => t.startsWith("image/")));
  if (!clipboardItem)
    throw new Error("No image in clipboard");
  const mime = clipboardItem.types.find((t) => t.startsWith("image/"));
  const blob = await clipboardItem.getType(mime);
  const ext = mime.split("/")[1] || "png";
  const filename = `image-${Date.now()}.${ext}`;
  const fileOrBlob = typeof File !== "undefined" ? new File([blob], filename, { type: mime }) : blob;
  const uploaderInstance = uploader ?? new CloudinaryUploader({
    cloud_name: settings.cloudName || settings.cloud_name,
    api_key: settings.apiKey || settings.api_key,
    upload_preset: settings.uploadPreset || settings.upload_preset,
    api_secret: settings.allowStoreApiSecret ? settings.apiSecret || settings.api_secret : void 0
  });
  const url = await uploaderInstance.upload(fileOrBlob, filename);
  return { url, filename };
}

// src/file-handler.ts
async function processFileCreate(app, settings, file, uploaderCtor = CloudinaryUploader, options = {}) {
  const notify = options.notify ?? (() => {
  });
  if (!file || !file.extension)
    return;
  const ext = (file.extension || "").toLowerCase();
  const imageExts = ["png", "jpg", "jpeg", "gif", "webp", "svg"];
  if (!imageExts.includes(ext))
    return;
  const data = await app.vault.readBinary(file);
  const sizeBytes = data?.byteLength ?? data?.length ?? 0;
  if (settings.localCopyEnabled && settings.localCopyFolder) {
    try {
      const folder = sanitizeFolderPath(settings.localCopyFolder);
      const destPath = folder ? `${folder}/${file.name}` : file.name;
      const exists = await app.vault.adapter.exists(destPath);
      let finalPath = destPath;
      if (exists) {
        const timestamp = Date.now();
        finalPath = destPath.replace(`.${ext}`, `-${timestamp}.${ext}`);
      }
      await app.vault.createBinary(finalPath, data);
      notify(`\u2705 Copied image to ${finalPath}`);
    } catch (e) {
      notify("\u274C Could not copy image locally: invalid folder path or permission error.");
    }
  }
  if (settings.autoUploadOnFileAdd && settings.cloudName && (settings.apiKey || settings.uploadPreset)) {
    let getMimeFromExt = function(ext2) {
      switch ((ext2 || "").toLowerCase()) {
        case "jpg":
        case "jpeg":
          return "image/jpeg";
        case "png":
          return "image/png";
        case "gif":
          return "image/gif";
        case "webp":
          return "image/webp";
        case "svg":
          return "image/svg+xml";
        default:
          return "application/octet-stream";
      }
    };
    const maxMB = settings.maxAutoUploadSizeMB ?? 0;
    if (maxMB > 0 && sizeBytes > maxMB * 1024 * 1024) {
      notify(`\u26A0\uFE0F Skipping auto-upload: file exceeds max size (${maxMB} MB)`);
      return;
    }
    const mime = getMimeFromExt(ext);
    const blob = new Blob([data], { type: mime });
    while (concurrentUploads >= MAX_CONCURRENT_UPLOADS) {
      await new Promise((r) => setTimeout(r, 200));
    }
    concurrentUploads++;
    try {
      const uploader = new uploaderCtor({
        cloud_name: settings.cloudName,
        api_key: settings.apiKey,
        upload_preset: settings.uploadPreset
      });
      notify("\u23F3 Auto uploading image...");
      const url = await uploader.upload(blob, file.name);
      notify(`\u2705 Image uploaded: ${url}`);
      const view = app.workspace.getActiveViewOfType?.(null);
      if (view && view.editor) {
        const content = view.editor.getValue();
        const esc = escapeRegExp(file.path);
        const imageRegex = new RegExp(`!\\[([^\\]]*)\\]\\(${esc}\\)`, "g");
        if (imageRegex.test(content)) {
          const newContent = content.replace(imageRegex, `![$1](${url})`);
          view.editor.setValue(newContent);
          notify("\u{1F501} Replaced local image reference with Cloudinary URL in the current editor.");
        }
      }
      return { uploadedUrl: url };
    } finally {
      concurrentUploads--;
    }
  }
}
var concurrentUploads = 0;
var MAX_CONCURRENT_UPLOADS = 3;
function escapeRegExp(str) {
  return str.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}
function sanitizeFolderPath(value) {
  if (!value)
    return "";
  if (/\.\.|^[A-Za-z]:\\\\|^\//.test(value)) {
    throw new Error("Invalid folder path");
  }
  return value.replace(/^\/+|\/+$/g, "");
}

// src/main.ts
var DEFAULT_SETTINGS = {
  cloudName: "",
  apiKey: "",
  apiSecret: "",
  uploadPreset: "",
  autoUploadOnFileAdd: false,
  localCopyEnabled: false,
  localCopyFolder: "",
  maxAutoUploadSizeMB: 10
};
var CloudinaryPlugin = class extends import_obsidian.Plugin {
  constructor() {
    super(...arguments);
    this.settings = DEFAULT_SETTINGS;
  }
  async onload() {
    await this.loadSettings();
    this.addCommand({
      id: "cloudinary-paste-image",
      name: "Paste image to Cloudinary",
      callback: () => this.pasteImage()
    });
    this.addCommand({
      id: "cloudinary-paste-hotkey",
      name: "Paste image (Quick)",
      hotkeys: [{ modifiers: ["Ctrl", "Shift"], key: "v" }],
      callback: () => this.pasteImage()
    });
    this.addSettingTab(new CloudinarySettingTab(this.app, this));
    this.registerEvent(this.app.vault.on("create", (file) => {
      this.handleFileCreate?.(file);
    }));
  }
  async pasteImage() {
    if (!this.settings.cloudName || !this.settings.apiKey && !this.settings.uploadPreset) {
      new import_obsidian.Notice("\u274C Configure Cloudinary credentials first! (Cloud name + API key or upload preset)");
      return;
    }
    try {
      new import_obsidian.Notice("\u23F3 Uploading...");
      const { url } = await pasteClipboardImage(this.settings, void 0, navigator.clipboard);
      const view = this.app.workspace.getActiveViewOfType(import_obsidian.MarkdownView);
      if (view && view.editor) {
        view.editor.replaceSelection(`![image](${url})`);
      } else {
        new import_obsidian.Notice(`\u2705 Image uploaded: ${url}`);
      }
      new import_obsidian.Notice("\u2705 Image uploaded!");
    } catch (err) {
      const message = err instanceof Error ? err.message : String(err);
      new import_obsidian.Notice(`\u274C Error: ${message}`);
    }
  }
  async handleFileCreate(file) {
    try {
      await processFileCreate(this.app, this.settings, file, CloudinaryUploader);
    } catch (err) {
      const msg = err instanceof Error ? err.message : String(err);
      new import_obsidian.Notice(`\u274C Auto-upload error: ${msg}`);
    }
  }
  async loadSettings() {
    this.settings = Object.assign({}, DEFAULT_SETTINGS, await this.loadData());
  }
  async saveSettings() {
    await this.saveData(this.settings);
  }
};
var CloudinarySettingTab = class extends import_obsidian.PluginSettingTab {
  constructor(app, plugin) {
    super(app, plugin);
    this.plugin = plugin;
  }
  display() {
    const { containerEl } = this;
    containerEl.empty();
    containerEl.createEl("h2", { text: "\u2601\uFE0F Cloudinary Settings" });
    new import_obsidian.Setting(containerEl).setName("Cloud Name").setDesc("Your Cloudinary cloud name").addText((text) => text.setPlaceholder("my-cloud").setValue(this.plugin.settings.cloudName).onChange(async (value) => {
      this.plugin.settings.cloudName = value;
      await this.plugin.saveSettings();
    }));
    new import_obsidian.Setting(containerEl).setName("API Key").setDesc("Your Cloudinary API key (public)").addText((text) => text.setPlaceholder("abc123...").setValue(this.plugin.settings.apiKey).onChange(async (value) => {
      this.plugin.settings.apiKey = value;
      await this.plugin.saveSettings();
    }));
    new import_obsidian.Setting(containerEl).setName("Allow storing API Secret (dangerous)").setDesc("When enabled, you may store your Cloudinary API secret in the plugin (NOT RECOMMENDED). This will enable signed uploads from the plugin.").addToggle((toggle) => toggle.setValue(!!this.plugin.settings.allowStoreApiSecret).onChange(async (value) => {
      this.plugin.settings.allowStoreApiSecret = value;
      if (!value) {
        this.plugin.settings.apiSecret = "";
      }
      await this.plugin.saveSettings();
      if (!value)
        new import_obsidian.Notice("\u26A0\uFE0F Storing API secret is disabled. Use unsigned uploads or server-side signing.");
    }));
    let secretText;
    new import_obsidian.Setting(containerEl).setName("API Secret (Optional)").setDesc("If you enabled storing API Secret above, enter it here. Storing the secret is dangerous \u2014 prefer unsigned uploads or server-side signing.").addText((text) => text.setPlaceholder("xyz789...").setValue(this.plugin.settings.apiSecret).setDisabled(!this.plugin.settings.allowStoreApiSecret).onChange(async (value) => {
      if (!this.plugin.settings.allowStoreApiSecret) {
        new import_obsidian.Notice('Enable "Allow storing API Secret" before entering a secret.');
        return;
      }
      this.plugin.settings.apiSecret = value;
      await this.plugin.saveSettings();
    }));
    new import_obsidian.Setting(containerEl).setName("Upload preset (Optional)").setDesc("Use upload preset for unsigned uploads (recommended instead of exposing secret)").addText((text) => text.setPlaceholder("my_unsigned_preset").setValue(this.plugin.settings.uploadPreset || "").onChange(async (value) => {
      this.plugin.settings.uploadPreset = value;
      await this.plugin.saveSettings();
    }));
    new import_obsidian.Setting(containerEl).setName("Max auto-upload size (MB)").setDesc("Maximum file size (in MB) allowed for automatic uploads. Files larger will not be uploaded automatically.").addText((text) => text.setPlaceholder("10").setValue(String(this.plugin.settings.maxAutoUploadSizeMB ?? 10)).onChange(async (value) => {
      const num = Number(value);
      if (!isFinite(num) || num <= 0) {
        new import_obsidian.Notice("Please enter a positive number for max upload size (MB)");
        return;
      }
      this.plugin.settings.maxAutoUploadSizeMB = num;
      await this.plugin.saveSettings();
    }));
    new import_obsidian.Setting(containerEl).setName("Auto upload on file add").setDesc("When enabled, new image files added to the vault will be uploaded automatically to Cloudinary.").addToggle((toggle) => toggle.setValue(!!this.plugin.settings.autoUploadOnFileAdd).onChange(async (value) => {
      this.plugin.settings.autoUploadOnFileAdd = value;
      await this.plugin.saveSettings();
    }));
    let folderText;
    new import_obsidian.Setting(containerEl).setName("Enable local copy").setDesc("If enabled, a local copy of new images will be made into the folder below (optional).").addToggle((toggle) => toggle.setValue(!!this.plugin.settings.localCopyEnabled).onChange(async (value) => {
      this.plugin.settings.localCopyEnabled = value;
      await this.plugin.saveSettings();
      if (folderText)
        folderText.setDisabled(!value);
    }));
    new import_obsidian.Setting(containerEl).setName("Local copy folder (relative to vault root)").setDesc("Example: assets/images \u2014 leave empty to use vault root. Only used when local copy is enabled.").addText((text) => {
      folderText = text;
      text.setPlaceholder("assets/images").setValue(this.plugin.settings.localCopyFolder || "").setDisabled(!this.plugin.settings.localCopyEnabled).onChange(async (value) => {
        if (value && /\.\.|^[A-Za-z]:\\\\|^\//.test(value)) {
          new import_obsidian.Notice('Invalid folder path: do not use ".." or absolute paths. Please use a relative path like "assets/images".');
          return;
        }
        const sanitized = value.replace(/^\/+|\/+$/g, "");
        this.plugin.settings.localCopyFolder = sanitized;
        await this.plugin.saveSettings();
      });
    });
    containerEl.createEl("hr");
    containerEl.createEl("p", {
      text: "\u{1F4DD} Get credentials: https://cloudinary.com/console/settings/api-keys"
    });
  }
};
